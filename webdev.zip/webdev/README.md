# Cake-Website

All dependencies files are here you can download 

and

follow up with the video for **index.html** and **style.css**

