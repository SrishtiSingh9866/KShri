const signInForm = document.getElementById("signInForm");
const signUpForm = document.getElementById("signUpForm");
const toggleLinks = document.querySelectorAll(".toggle");

// Function to toggle between sign-in and sign-up forms
function toggleForms() {
  document.querySelector("main").classList.toggle("sign-up-mode");
}

// Default login credentials
const defaultUsername = "admin";
const defaultPassword = "password123";

// Function to save user information on sign up
signUpForm.addEventListener("submit", function(event) {
  event.preventDefault();
  console.log("Sign up form submitted");
  const newUsername = document.getElementById("newUsername").value;
  const newEmail = document.getElementById("newEmail").value;
  const newPassword = document.getElementById("newPassword").value;
  console.log("New username:", newUsername);
  console.log("New email:", newEmail);
  console.log("New password:", newPassword);

  // Save user information here (you can use local storage, database, etc.)
  // For example, you can use localStorage:
  localStorage.setItem("username", newUsername);
  localStorage.setItem("email", newEmail);
  localStorage.setItem("password", newPassword);

  // Redirect to index.html after successful sign up
  window.location.href = "index.html";
});

// Function to handle sign in
signInForm.addEventListener("submit", function(event) {
  event.preventDefault();
  console.log("Sign in form submitted");
  const username = document.getElementById("username").value;
  const password = document.getElementById("password").value;
  console.log("Username:", username);
  console.log("Password:", password);

  // Retrieve user information (for example, from localStorage)
  const storedUsername = localStorage.getItem("username");
  const storedPassword = localStorage.getItem("password");
  console.log("Stored username:", storedUsername);
  console.log("Stored password:", storedPassword);

  // Check if the entered username and password match the stored ones
  if (username === storedUsername && password === storedPassword) {
    // Redirect to index.html after successful sign in
    window.location.href = "index.html";
  } else {
    // Show an alert notification for incorrect username or password
    alert("Incorrect username or password");
  }
});

// Adding default login credentials to localStorage for testing
localStorage.setItem("username", defaultUsername);
localStorage.setItem("password", defaultPassword);

// Adding event listeners to toggle links
toggleLinks.forEach(link => {
  link.addEventListener("click", toggleForms);
});
